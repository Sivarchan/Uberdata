### Images from the output plot
